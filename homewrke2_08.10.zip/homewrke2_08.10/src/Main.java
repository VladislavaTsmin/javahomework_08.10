import java.util.Scanner;

//Напишите программу, которая принимает от пользователя его имя, возраст (полных лет) и вес.
// Когда все данные введены, программа должна выдать сообщение:
// «Уважаемый, [Имя]! В свои [Возраст] лет Вы для нас дороги, как [Вес] килограмм золота.».
// В сообщении [Имя], [Возраст] и [Вес] должны принять введённые значения.
public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        System.out.println("Введите своё имя: ");
        String name = String.valueOf(scan.next());
        System.out.println("Введите свой возраст: ");
        int age = scan.nextInt();
        System.out.println("Введите свой вес: ");
        float weight = scan.nextFloat();

        System.out.printf("Уважаемый %s !", name);
        System.out.printf("В свои %d  лет Вы для нас дороги, ", age);
        System.out.printf("как %s  килограмм золота." , weight );





    }
}