import java.util.Scanner;

//Напишите программу, которая получает от пользователя два целых числа и затем
// вычисляет сумму (сложение), разницу (вычитание), произведение (умножение) и частное (деление)
// введённых чисел.
// Результат вычислений выведите в консоль.
public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        System.out.println("Введите первое число: ");
        int number1 = scan.nextInt();
        System.out.println("Введите второе число: ");
        int number2 = scan.nextInt();

        int a = number1 + number2;

        System.out.println(" Результат сложения ваших чисел: " + a );
        System.out.print(" Результат вычитания ваших чисел: " );
        System.out.println(number1 - number2);
        System.out.println(" Результат умножения ваших чисел: " + number1 * number2);
        System.out.println(" Результат деления ваших чисел: " + number1 / number2);
    }
}