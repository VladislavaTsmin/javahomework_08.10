import java.util.Random;
import java.util.UUID;

// Напишите программу, в которой объявите переменные всех примитивных типов.
// Значение для каждой переменной сгенерируйте с помощью класса Random.
// При необходимости используйте приведение типов. Полученные значения выведите в консоль.

//В этой же программе создайте переменную типа String. Сгенерируйте значение для строки.
// При необходимости используйте метод String.valueOf(). Ограничений на длину строки и содержимое нет.
// Полученное значение выведите в консоль.

public class Main {
    public static void main(String[] args) {
        Random rnd = new Random();

        int inT = rnd.nextInt();
        float flo = rnd.nextFloat();
        Boolean bool = rnd.nextBoolean();
        String str = String.valueOf(UUID.randomUUID().toString());


        System.out.printf("Случайное значение числа int: %d", inT);
        System.out.println();
        System.out.printf("Случайное значение числа float: %s", flo);
        System.out.println();
        System.out.printf("Случайное значение числа Boolean: %s", bool);
        System.out.println();
        System.out.printf("Случайное значение числа String: %s", str);




    }
}